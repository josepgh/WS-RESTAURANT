<?php
session_start();
$valor_seleccionado = $_POST['mi_select'] ?? '';
$modo = $_POST['modo'] ?? '';

// Redirige según el modo
if ($modo === 'get') {
    header("Location: pagina1_get.php?mi_select=" . urlencode($valor_seleccionado));
} else {
    $_SESSION['mi_select'] = $valor_seleccionado;
    header("Location: pagina1_session.php");
}
exit();
?>