<?php
$host = 'localhost';
$usuario = 'usuario';
$contrasena = 'contraseña';
$base_de_datos = 'nombre_base_datos';

$conn = new mysqli($host, $usuario, $contrasena, $base_de_datos);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>