<?php
session_start();
include 'conexion.php';
$valor_seleccionado = $_SESSION['mi_select'] ?? '';
?>
<!DOCTYPE html>
<html>
<head><title>Formulario SESSION</title></head>
<body>
    <h2>Formulario con SESSION</h2>
    <form action="pagina2.php" method="POST">
        <select name="mi_select">
            <?php
            $resultado = $conn->query("SELECT id, nombre FROM tabla");

            while ($fila = $resultado->fetch_assoc()) {
                $selected = ($fila['id'] == $valor_seleccionado) ? 'selected' : '';
                echo "<option value='{$fila['id']}' $selected>{$fila['nombre']}</option>";
            }
            ?>
        </select>
        <button type="submit">Enviar</button>
        <input type="hidden" name="modo" value="session">
    </form>
</body>
</html>