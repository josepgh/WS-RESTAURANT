<?php
$conn = new mysqli("localhost", "root", "", "nombre_de_tu_bd");

if (isset($_POST["subcategoria_id"])) {
    $subcategoria_id = $_POST["subcategoria_id"];

    $sql = "SELECT id, nombre FROM productos WHERE subcategoria_id = $subcategoria_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo '<option value="">-- Selecciona producto --</option>';
        while ($row = $result->fetch_assoc()) {
            echo '<option value="'.$row['id'].'">'.$row['nombre'].'</option>';
        }
    } else {
        echo '<option value="">No hay productos</option>';
    }
}
?>