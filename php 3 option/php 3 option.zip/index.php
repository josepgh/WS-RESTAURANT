<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Desplegables dependientes (3 niveles)</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

    <h2>Categoría:</h2>
    <select id="categoria">
        <option value="">-- Selecciona categoría --</option>
        <?php
        $conn = new mysqli("localhost", "root", "", "nombre_de_tu_bd");
        $sql = "SELECT id, nombre FROM categorias";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            echo "<option value='".$row['id']."'>".$row['nombre']."</option>";
        }
        ?>
    </select>

    <h2>Subcategoría:</h2>
    <select id="subcategoria">
        <option value="">-- Selecciona subcategoría --</option>
    </select>

    <h2>Producto:</h2>
    <select id="producto">
        <option value="">-- Selecciona producto --</option>
    </select>

    <script>
        $(document).ready(function(){
            $('#categoria').on('change', function(){
                var categoriaID = $(this).val();
                if(categoriaID){
                    $.ajax({
                        type: 'POST',
                        url: 'obtener_subcategorias.php',
                        data: {categoria_id: categoriaID},
                        success: function(html){
                            $('#subcategoria').html(html);
                            $('#producto').html('<option value="">-- Selecciona producto --</option>');
                        }
                    });
                } else {
                    $('#subcategoria').html('<option value="">-- Selecciona subcategoría --</option>');
                    $('#producto').html('<option value="">-- Selecciona producto --</option>');
                }
            });

            $('#subcategoria').on('change', function(){
                var subcategoriaID = $(this).val();
                if(subcategoriaID){
                    $.ajax({
                        type: 'POST',
                        url: 'obtener_productos.php',
                        data: {subcategoria_id: subcategoriaID},
                        success: function(html){
                            $('#producto').html(html);
                        }
                    });
                } else {
                    $('#producto').html('<option value="">-- Selecciona producto --</option>');
                }
            });
        });
    </script>

</body>
</html>